
export interface Review {
  id: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  category: 'Jackets' | 'Hoodies' | 'T-Shirts' | 'Baggy Jeans' | 'Head Warmers';
  image: string;
  description: string;
  tag: string;
  sizes: string[];
  colors: string[];
  material: string;
  reviews: Review[];
}

export interface CartItem extends Product {
  quantity: number;
  selectedSize?: string;
  selectedColor?: string;
}

export interface GroundingSource {
  web?: {
    uri: string;
    title: string;
  };
}

export enum PaymentMethod {
  TRANSFER = 'Bank Transfer',
  USSD = 'USSD',
  CARD = 'Debit Card'
}

export interface Bank {
  name: string;
  code: string;
}
