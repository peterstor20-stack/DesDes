
import { Product, Bank } from './types';

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Oversized "Des" Hoodie',
    price: 35000,
    category: 'Hoodies',
    image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&q=80&w=800',
    description: 'Heavyweight fleece with drop shoulders and distressed details. Perfect for the Lagos breeze.',
    tag: 'Best Seller',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Midnight Black', 'Slate Grey', 'Off-White'],
    material: '80% Cotton, 20% Polyester Fleece',
    reviews: [
      { id: 'r1', userName: 'Tunde O.', rating: 5, comment: 'Best hoodie I own. The fit is perfect for that baggy look.', date: '2024-03-15' },
      { id: 'r2', userName: 'Amaka E.', rating: 4, comment: 'Very warm, maybe too warm for Lagos heat but great for travel.', date: '2024-03-10' }
    ]
  },
  {
    id: '2',
    name: '90s Baggy Denim',
    price: 42000,
    category: 'Baggy Jeans',
    image: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&q=80&w=800',
    description: 'Ultra-wide leg denim with reinforced stitching and acid wash finish.',
    tag: 'Trending',
    sizes: ['30', '32', '34', '36'],
    colors: ['Vintage Blue', 'Onyx Black'],
    material: '14oz Raw Selvedge Denim',
    reviews: [
      { id: 'r3', userName: 'Chidi K.', rating: 5, comment: 'Proper 90s vibes. Heavy denim, feels like it will last forever.', date: '2024-03-12' }
    ]
  },
  {
    id: '3',
    name: 'Tech-Shell Utility Jacket',
    price: 55000,
    category: 'Jackets',
    image: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&q=80&w=800',
    description: 'Water-resistant shell with multiple cargo pockets and reflective branding.',
    tag: 'Limited',
    sizes: ['M', 'L', 'XL'],
    colors: ['Reflective Silver', 'Tactical Olive'],
    material: 'Ripstop Nylon with DWR Coating',
    reviews: [
      { id: 'r4', userName: 'Ibrahim S.', rating: 5, comment: 'The reflective parts look insane at night. Real techwear.', date: '2024-03-05' }
    ]
  },
  {
    id: '4',
    name: 'Knitted "Cold Day" Beanie',
    price: 12000,
    category: 'Head Warmers',
    image: 'https://images.unsplash.com/photo-1576871337622-98d48d365350?auto=format&fit=crop&q=80&w=800',
    description: 'Soft-touch rib knit beanie with embroidered "Des Des" logo.',
    tag: 'Essential',
    sizes: ['One Size'],
    colors: ['Safety Orange', 'Black', 'Sand'],
    material: '100% Recycled Acrylic',
    reviews: [
      { id: 'r5', userName: 'Zainab A.', rating: 4, comment: 'Nice and snug. Color is exactly as shown.', date: '2024-02-28' }
    ]
  },
  {
    id: '5',
    name: 'Graphic Box Tee',
    price: 18000,
    category: 'T-Shirts',
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&q=80&w=800',
    description: '240GSM cotton tee with high-density screen print of Abuja landscape.',
    tag: 'New Drop',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: ['Pure White', 'Pitch Black'],
    material: '240GSM Heavyweight Combed Cotton',
    reviews: []
  },
  {
    id: '6',
    name: 'Cargo Flare Jeans',
    price: 38000,
    category: 'Baggy Jeans',
    image: 'https://images.unsplash.com/photo-1604176354204-9268737828e4?auto=format&fit=crop&q=80&w=800',
    description: 'Hybrid between cargo pants and flare denim. Bold silhouette.',
    tag: 'Hottest',
    sizes: ['28', '30', '32', '34'],
    colors: ['Deep Indigo', 'Washer Black'],
    material: '12oz Stretch Denim',
    reviews: []
  }
];

// Added NIGERIAN_BANKS export to fix missing export error in Checkout.tsx
export const NIGERIAN_BANKS: Bank[] = [
  { name: 'Access Bank', code: '044' },
  { name: 'Guaranty Trust Bank', code: '058' },
  { name: 'Zenith Bank', code: '057' },
  { name: 'United Bank for Africa', code: '033' },
  { name: 'First Bank of Nigeria', code: '011' },
  { name: 'Kuda Bank', code: '50211' }
];
