
import React, { useState, useEffect } from 'react';
import { PRODUCTS as INITIAL_PRODUCTS } from './constants.tsx';
import { Product, CartItem, Review } from './types';
import GeminiStudio from './components/GeminiStudio';
import TrendFinder from './components/TrendFinder';
import Checkout from './components/Checkout';

const App: React.FC = () => {
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isStudioOpen, setIsStudioOpen] = useState(false);
  const [viewingProduct, setViewingProduct] = useState<Product | null>(null);
  
  // Selection states for adding to cart
  const [selection, setSelection] = useState<{ id: string, size: string, color: string } | null>(null);

  // Review form state
  const [reviewName, setReviewName] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');

  const handleSelection = (productId: string, type: 'size' | 'color', value: string) => {
    setSelection(prev => {
      const current = prev?.id === productId ? prev : { id: productId, size: '', color: '' };
      return { ...current, [type]: value };
    });
  };

  const addToCart = (product: Product) => {
    const currentSelection = selection?.id === product.id ? selection : null;
    const size = currentSelection?.size || product.sizes[0];
    const color = currentSelection?.color || product.colors[0];

    setCart(prev => {
      const existing = prev.find(item => 
        item.id === product.id && 
        item.selectedSize === size && 
        item.selectedColor === color
      );
      if (existing) {
        return prev.map(item => 
          (item.id === product.id && item.selectedSize === size && item.selectedColor === color) 
            ? { ...item, quantity: item.quantity + 1 } 
            : item
        );
      }
      return [...prev, { ...product, quantity: 1, selectedSize: size, selectedColor: color }];
    });
  };

  const removeFromCart = (id: string, size?: string, color?: string) => {
    setCart(prev => prev.filter(item => !(item.id === id && item.selectedSize === size && item.selectedColor === color)));
  };

  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!viewingProduct || !reviewName || !reviewComment) return;

    const newReview: Review = {
      id: Math.random().toString(36).substr(2, 9),
      userName: reviewName,
      rating: reviewRating,
      comment: reviewComment,
      date: new Date().toISOString().split('T')[0]
    };

    const updatedProducts = products.map(p => {
      if (p.id === viewingProduct.id) {
        return { ...p, reviews: [newReview, ...p.reviews] };
      }
      return p;
    });

    setProducts(updatedProducts);
    setViewingProduct({ ...viewingProduct, reviews: [newReview, ...viewingProduct.reviews] });
    setReviewName('');
    setReviewComment('');
    setReviewRating(5);
  };

  const handleShare = (platform: string) => {
    if (!viewingProduct) return;
    const url = window.location.href;
    const text = `Check out this drip from Des Des: ${viewingProduct.name} 🔥`;
    
    switch (platform) {
      case 'twitter':
        window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`, '_blank');
        break;
      case 'instagram':
      case 'tiktok':
        // Direct web sharing to IG/TikTok is limited; copying link is the best alternative
        navigator.clipboard.writeText(`${text} ${url}`);
        alert(`Link copied! Share the heat on ${platform.charAt(0).toUpperCase() + platform.slice(1)}.`);
        break;
    }
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handleCheckoutSuccess = () => {
    setIsCheckoutOpen(false);
    setCart([]);
    alert("ORDER RECEIVED! 🔥 We're prepping your drip right now.");
  };

  const calculateAverageRating = (reviews: Review[]) => {
    if (reviews.length === 0) return 0;
    const sum = reviews.reduce((acc, r) => acc + r.rating, 0);
    return (sum / reviews.length).toFixed(1);
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-black/80 backdrop-blur-md border-b border-zinc-800 px-6 py-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-8">
            <h1 className="text-3xl font-black italic tracking-tighter uppercase select-none">Des Des</h1>
            <div className="hidden md:flex gap-6 text-sm font-medium text-zinc-400 uppercase tracking-widest">
              <a href="#" className="hover:text-white transition">Shop</a>
              <a href="#" className="hover:text-white transition">Studio</a>
              <a href="#" className="hover:text-white transition">Collections</a>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsStudioOpen(!isStudioOpen)}
              className="bg-purple-600/10 text-purple-400 border border-purple-500/20 px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider hover:bg-purple-600/20 transition"
            >
              AI Studio
            </button>
            <button 
              onClick={() => setIsCartOpen(true)}
              className="relative p-2 text-zinc-400 hover:text-white"
            >
              <i className="fa-solid fa-bag-shopping text-xl"></i>
              {cart.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-yellow-400 text-black text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center">
                  {cart.reduce((a, b) => a + b.quantity, 0)}
                </span>
              )}
            </button>
          </div>
        </div>
      </nav>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative h-[80vh] flex items-center justify-center overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1523381210434-271e8be1f52b?auto=format&fit=crop&q=80&w=1920" 
            className="absolute inset-0 w-full h-full object-cover opacity-60"
            alt="Hero Background"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/50"></div>
          <div className="relative text-center px-6">
            <span className="text-yellow-400 font-bold uppercase tracking-[0.3em] text-sm mb-4 block">New Season Drop</span>
            <h2 className="text-6xl md:text-8xl font-black italic uppercase tracking-tighter mb-8 leading-none">
              Youth Culture<br/>Defined.
            </h2>
            <button className="bg-white text-black font-black px-10 py-5 rounded-full text-lg uppercase tracking-widest hover:scale-105 transition active:scale-95">
              Shop Now
            </button>
          </div>
        </section>

        {/* Trend Pulse (Gemini Grounding) */}
        <TrendFinder />

        {/* AI Studio Toggle */}
        {isStudioOpen && (
          <section className="py-12 px-6 bg-zinc-950">
            <div className="max-w-4xl mx-auto">
              <div className="mb-6 flex justify-between items-end">
                <div>
                  <h2 className="text-3xl font-black uppercase italic tracking-tighter">Customizer Studio</h2>
                  <p className="text-zinc-500 text-sm">Powered by Gemini 2.5 & Veo 3.1</p>
                </div>
                <button onClick={() => setIsStudioOpen(false)} className="text-zinc-500 hover:text-white">Close Studio</button>
              </div>
              <GeminiStudio initialImage={selectedProduct?.image} />
            </div>
          </section>
        )}

        {/* Products Grid */}
        <section className="py-20 px-6">
          <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-end mb-12">
              <h2 className="text-4xl font-black italic uppercase tracking-tighter">Current Drops</h2>
              <div className="flex gap-2">
                {['All', 'Hoodies', 'Jeans', 'Tees'].map(cat => (
                  <button key={cat} className="px-4 py-2 border border-zinc-800 rounded-full text-xs font-bold uppercase hover:bg-zinc-800 transition">
                    {cat}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {products.map(product => (
                <div key={product.id} className="group relative flex flex-col">
                  <div className="aspect-[3/4] bg-zinc-900 rounded-3xl overflow-hidden mb-6 relative">
                    <img 
                      src={product.image} 
                      alt={product.name}
                      className="w-full h-full object-cover transition duration-700 group-hover:scale-110"
                    />
                    <div className="absolute top-4 left-4 flex flex-col gap-2">
                      <span className="bg-black/80 backdrop-blur-md px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest text-yellow-400 border border-yellow-400/30">
                        {product.tag}
                      </span>
                      {product.reviews.length > 0 && (
                        <div className="bg-black/80 backdrop-blur-md px-3 py-1.5 rounded-full text-[10px] font-black text-white border border-zinc-800 flex items-center gap-1">
                          <i className="fa-solid fa-star text-yellow-400"></i>
                          {calculateAverageRating(product.reviews)}
                        </div>
                      )}
                    </div>
                    <div className="absolute top-4 right-4 flex flex-col gap-2">
                      <button 
                        onClick={() => { setSelectedProduct(product); setIsStudioOpen(true); }}
                        className="w-10 h-10 bg-white/10 backdrop-blur-md text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition duration-300 hover:bg-white hover:text-black"
                        title="Open in AI Studio"
                      >
                        <i className="fa-solid fa-wand-magic-sparkles"></i>
                      </button>
                      <button 
                        onClick={() => setViewingProduct(product)}
                        className="w-10 h-10 bg-white/10 backdrop-blur-md text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition duration-300 hover:bg-white hover:text-black"
                        title="View Details & Reviews"
                      >
                        <i className="fa-solid fa-eye"></i>
                      </button>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-start mb-4">
                    <div onClick={() => setViewingProduct(product)} className="cursor-pointer">
                      <h3 className="font-bold text-lg mb-1 group-hover:text-yellow-400 transition">{product.name}</h3>
                      <p className="text-zinc-500 text-xs mb-2">{product.material}</p>
                    </div>
                    <p className="font-black text-lg">₦{product.price.toLocaleString()}</p>
                  </div>

                  <div className="space-y-4 flex-1">
                    {/* Size Selection */}
                    <div>
                      <p className="text-[10px] uppercase font-bold text-zinc-500 mb-2 tracking-widest">Select Size</p>
                      <div className="flex flex-wrap gap-2">
                        {product.sizes.map(size => (
                          <button
                            key={size}
                            onClick={() => handleSelection(product.id, 'size', size)}
                            className={`px-3 py-1.5 rounded-lg text-[10px] font-bold border transition ${
                              (selection?.id === product.id ? selection.size : product.sizes[0]) === size 
                                ? 'bg-white text-black border-white' 
                                : 'border-zinc-800 text-zinc-400 hover:border-zinc-600'
                            }`}
                          >
                            {size}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Color Selection */}
                    <div>
                      <p className="text-[10px] uppercase font-bold text-zinc-500 mb-2 tracking-widest">Select Color</p>
                      <div className="flex flex-wrap gap-2">
                        {product.colors.map(color => (
                          <button
                            key={color}
                            onClick={() => handleSelection(product.id, 'color', color)}
                            className={`px-3 py-1.5 rounded-lg text-[10px] font-bold border transition ${
                              (selection?.id === product.id ? selection.color : product.colors[0]) === color 
                                ? 'bg-white text-black border-white' 
                                : 'border-zinc-800 text-zinc-400 hover:border-zinc-600'
                            }`}
                          >
                            {color}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <button 
                    onClick={() => addToCart(product)}
                    className="w-full mt-6 py-4 border border-zinc-800 rounded-2xl font-black uppercase tracking-widest hover:bg-white hover:text-black hover:border-white transition-all duration-300"
                  >
                    Add to Bag
                  </button>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      {/* Product Details Modal */}
      {viewingProduct && (
        <div className="fixed inset-0 z-[120] bg-black/90 backdrop-blur-xl flex items-center justify-center p-4">
          <div className="w-full max-w-5xl bg-zinc-950 border border-zinc-800 rounded-[2rem] overflow-hidden flex flex-col md:flex-row max-h-[90vh]">
            <div className="w-full md:w-1/2 relative bg-zinc-900">
              <img src={viewingProduct.image} alt={viewingProduct.name} className="w-full h-full object-cover" />
              <button 
                onClick={() => setViewingProduct(null)}
                className="absolute top-6 left-6 w-10 h-10 bg-black/50 text-white rounded-full flex items-center justify-center hover:bg-white hover:text-black transition"
              >
                <i className="fa-solid fa-arrow-left"></i>
              </button>
            </div>
            
            <div className="w-full md:w-1/2 flex flex-col overflow-y-auto">
              <div className="p-8 md:p-12">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <span className="text-yellow-400 text-[10px] font-black uppercase tracking-[0.3em] mb-2 block">{viewingProduct.tag}</span>
                    <h2 className="text-4xl font-black italic uppercase tracking-tighter mb-2">{viewingProduct.name}</h2>
                    <div className="flex items-center gap-2 mb-4">
                      <div className="flex text-yellow-400 text-xs">
                        {[1, 2, 3, 4, 5].map(star => (
                          <i key={star} className={`fa-solid fa-star ${star > Number(calculateAverageRating(viewingProduct.reviews)) ? 'text-zinc-800' : ''}`}></i>
                        ))}
                      </div>
                      <span className="text-zinc-500 text-xs font-bold uppercase tracking-widest">({viewingProduct.reviews.length} Reviews)</span>
                    </div>
                  </div>
                  <p className="text-2xl font-black">₦{viewingProduct.price.toLocaleString()}</p>
                </div>

                <p className="text-zinc-400 leading-relaxed mb-6">{viewingProduct.description}</p>

                {/* Sharing Section */}
                <div className="mb-8 flex items-center gap-4">
                  <p className="text-[10px] uppercase font-black text-zinc-600 tracking-widest">Share Heat:</p>
                  <div className="flex gap-3">
                    <button 
                      onClick={() => handleShare('twitter')}
                      className="w-8 h-8 rounded-full border border-zinc-800 flex items-center justify-center text-zinc-400 hover:bg-white hover:text-black hover:border-white transition"
                      title="Share on Twitter"
                    >
                      <i className="fa-brands fa-twitter text-xs"></i>
                    </button>
                    <button 
                      onClick={() => handleShare('instagram')}
                      className="w-8 h-8 rounded-full border border-zinc-800 flex items-center justify-center text-zinc-400 hover:bg-white hover:text-black hover:border-white transition"
                      title="Share on Instagram"
                    >
                      <i className="fa-brands fa-instagram text-xs"></i>
                    </button>
                    <button 
                      onClick={() => handleShare('tiktok')}
                      className="w-8 h-8 rounded-full border border-zinc-800 flex items-center justify-center text-zinc-400 hover:bg-white hover:text-black hover:border-white transition"
                      title="Share on TikTok"
                    >
                      <i className="fa-brands fa-tiktok text-xs"></i>
                    </button>
                  </div>
                </div>
                
                <div className="space-y-6 mb-12">
                  <div className="flex gap-12">
                    <div>
                      <p className="text-[10px] uppercase font-black text-zinc-600 mb-2 tracking-widest">Material</p>
                      <p className="text-sm font-medium">{viewingProduct.material}</p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase font-black text-zinc-600 mb-2 tracking-widest">Category</p>
                      <p className="text-sm font-medium">{viewingProduct.category}</p>
                    </div>
                  </div>
                </div>

                {/* Reviews Section */}
                <div className="border-t border-zinc-900 pt-12">
                  <h3 className="text-xl font-black italic uppercase tracking-tighter mb-8">Culture's Verdict</h3>
                  
                  {/* Review Form */}
                  <form onSubmit={handleAddReview} className="bg-zinc-900/50 p-6 rounded-2xl mb-12 border border-zinc-800">
                    <p className="text-[10px] uppercase font-black text-yellow-400 mb-4 tracking-widest">Drop a Review</p>
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <input 
                        type="text" 
                        placeholder="Your Name" 
                        value={reviewName}
                        onChange={(e) => setReviewName(e.target.value)}
                        className="bg-zinc-800 border-none rounded-xl p-3 text-sm focus:ring-1 focus:ring-yellow-400 outline-none"
                        required
                      />
                      <select 
                        value={reviewRating}
                        onChange={(e) => setReviewRating(Number(e.target.value))}
                        className="bg-zinc-800 border-none rounded-xl p-3 text-sm focus:ring-1 focus:ring-yellow-400 outline-none appearance-none"
                      >
                        {[5, 4, 3, 2, 1].map(r => <option key={r} value={r}>{r} Stars</option>)}
                      </select>
                    </div>
                    <textarea 
                      placeholder="Share your experience with the drip..."
                      value={reviewComment}
                      onChange={(e) => setReviewComment(e.target.value)}
                      className="w-full bg-zinc-800 border-none rounded-xl p-3 text-sm focus:ring-1 focus:ring-yellow-400 outline-none resize-none h-24 mb-4"
                      required
                    />
                    <button type="submit" className="w-full bg-yellow-400 text-black font-black py-3 rounded-xl uppercase tracking-widest text-xs hover:bg-white transition">
                      Post Review
                    </button>
                  </form>

                  {/* Reviews List */}
                  <div className="space-y-8">
                    {viewingProduct.reviews.length === 0 ? (
                      <p className="text-zinc-600 text-center text-sm italic">No reviews yet. Be the first to verify the drip.</p>
                    ) : (
                      viewingProduct.reviews.map(review => (
                        <div key={review.id} className="group">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <p className="font-bold text-sm mb-1">{review.userName}</p>
                              <div className="flex text-yellow-400 text-[10px] gap-0.5">
                                {[1, 2, 3, 4, 5].map(s => (
                                  <i key={s} className={`fa-solid fa-star ${s > review.rating ? 'text-zinc-800' : ''}`}></i>
                                ))}
                              </div>
                            </div>
                            <span className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest">{review.date}</span>
                          </div>
                          <p className="text-zinc-400 text-sm leading-relaxed">{review.comment}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-zinc-950 border-t border-zinc-900 py-20 px-6">
        <div className="max-w-7xl mx-auto grid md:grid-cols-4 gap-12">
          <div className="md:col-span-2">
            <h3 className="text-4xl font-black italic uppercase tracking-tighter mb-6">Des Des</h3>
            <p className="text-zinc-500 max-w-sm mb-8">
              The intersection of Nigerian street style and futuristic AI technology. We don't just sell clothes; we build avatars.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 border border-zinc-800 rounded-full flex items-center justify-center hover:bg-white hover:text-black transition">
                <i className="fa-brands fa-instagram"></i>
              </a>
              <a href="#" className="w-10 h-10 border border-zinc-800 rounded-full flex items-center justify-center hover:bg-white hover:text-black transition">
                <i className="fa-brands fa-twitter"></i>
              </a>
              <a href="#" className="w-10 h-10 border border-zinc-800 rounded-full flex items-center justify-center hover:bg-white hover:text-black transition">
                <i className="fa-brands fa-tiktok"></i>
              </a>
            </div>
          </div>
          <div>
            <h4 className="font-bold uppercase tracking-widest text-xs mb-6 text-zinc-600">Explore</h4>
            <ul className="space-y-4 text-sm font-medium">
              <li><a href="#" className="text-zinc-400 hover:text-white">Shop All</a></li>
              <li><a href="#" className="text-zinc-400 hover:text-white">AI Studio</a></li>
              <li><a href="#" className="text-zinc-400 hover:text-white">Gift Cards</a></li>
              <li><a href="#" className="text-zinc-400 hover:text-white">Size Guide</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold uppercase tracking-widest text-xs mb-6 text-zinc-600">Support</h4>
            <ul className="space-y-4 text-sm font-medium">
              <li><a href="#" className="text-zinc-400 hover:text-white">Shipping</a></li>
              <li><a href="#" className="text-zinc-400 hover:text-white">Returns</a></li>
              <li><a href="#" className="text-zinc-400 hover:text-white">Contact Us</a></li>
              <li><a href="#" className="text-zinc-400 hover:text-white">FAQ</a></li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-20 pt-8 border-t border-zinc-900 flex flex-col md:flex-row justify-between text-[10px] uppercase font-bold text-zinc-700 tracking-[0.2em]">
          <p>© 2024 Des Des Enterprise. All Rights Reserved.</p>
          <div className="flex gap-8 mt-4 md:mt-0">
            <a href="#">Privacy Policy</a>
            <a href="#">Terms of Service</a>
          </div>
        </div>
      </footer>

      {/* Cart Drawer Overlay */}
      {isCartOpen && (
        <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm" onClick={() => setIsCartOpen(false)}>
          <div 
            className="absolute right-0 top-0 bottom-0 w-full max-w-md bg-zinc-900 p-8 flex flex-col"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-10">
              <h2 className="text-2xl font-black italic uppercase tracking-tighter">Your Bag</h2>
              <button onClick={() => setIsCartOpen(false)} className="text-2xl hover:text-zinc-400">
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-6">
              {cart.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center px-10">
                  <div className="w-16 h-16 bg-zinc-800 rounded-full flex items-center justify-center mb-6">
                    <i className="fa-solid fa-bag-shopping text-2xl text-zinc-600"></i>
                  </div>
                  <h3 className="font-bold mb-2 uppercase">Empty Bag</h3>
                  <p className="text-zinc-500 text-sm">Your drip is waiting. Go explore the collections.</p>
                </div>
              ) : (
                cart.map((item, idx) => (
                  <div key={`${item.id}-${idx}`} className="flex gap-4 group">
                    <div className="w-24 h-32 bg-zinc-800 rounded-xl overflow-hidden shrink-0">
                      <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 flex flex-col justify-between py-1">
                      <div>
                        <div className="flex justify-between items-start mb-1">
                          <h4 className="font-bold text-sm">{item.name}</h4>
                          <button onClick={() => removeFromCart(item.id, item.selectedSize, item.selectedColor)} className="text-zinc-600 hover:text-red-500 transition opacity-0 group-hover:opacity-100">
                            <i className="fa-solid fa-trash-can text-xs"></i>
                          </button>
                        </div>
                        <p className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold">
                          {item.selectedSize} / {item.selectedColor}
                        </p>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-medium">Qty: {item.quantity}</span>
                        <span className="font-bold">₦{(item.price * item.quantity).toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {cart.length > 0 && (
              <div className="mt-10 pt-10 border-t border-zinc-800">
                <div className="flex justify-between items-end mb-6">
                  <span className="text-zinc-500 uppercase tracking-widest text-[10px] font-bold">Subtotal</span>
                  <span className="text-2xl font-black italic tracking-tighter">₦{cartTotal.toLocaleString()}</span>
                </div>
                <button 
                  onClick={() => setIsCheckoutOpen(true)}
                  className="w-full bg-white text-black py-5 rounded-2xl font-black uppercase tracking-widest hover:scale-[1.02] transition active:scale-95"
                >
                  Checkout
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Checkout Modal */}
      {isCheckoutOpen && (
        <Checkout 
          items={cart} 
          total={cartTotal} 
          onClose={() => setIsCheckoutOpen(false)} 
          onSuccess={handleCheckoutSuccess}
        />
      )}
    </div>
  );
};

export default App;
