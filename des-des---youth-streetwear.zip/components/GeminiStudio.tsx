
import React, { useState, useRef } from 'react';
import { editImageWithGemini, generateVideoWithVeo } from '../services/geminiService';

interface GeminiStudioProps {
  initialImage?: string;
}

const GeminiStudio: React.FC<GeminiStudioProps> = ({ initialImage }) => {
  const [currentImage, setCurrentImage] = useState<string>(initialImage || 'https://picsum.photos/800/1000?random=studio');
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [status, setStatus] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (readerEvent) => {
        setCurrentImage(readerEvent.target?.result as string);
        setVideoUrl(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleEdit = async () => {
    if (!prompt) return;
    setLoading(true);
    setStatus('Gemini is reimagining your style...');
    try {
      const edited = await editImageWithGemini(currentImage, prompt);
      if (edited) setCurrentImage(edited);
    } catch (err) {
      console.error(err);
      setStatus('Edit failed. Try again.');
    } finally {
      setLoading(false);
      setStatus('');
    }
  };

  const handleAnimate = async () => {
    setLoading(true);
    setStatus('Veo is generating your cinematic loop (this takes a minute)...');
    try {
      const video = await generateVideoWithVeo(currentImage, prompt || 'Animate this fashion item elegantly');
      if (video) setVideoUrl(video);
    } catch (err) {
      console.error(err);
      setStatus('Animation failed. Ensure you have a valid Billing API Key.');
    } finally {
      setLoading(false);
      setStatus('');
    }
  };

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden">
      <div className="p-4 bg-zinc-800 flex justify-between items-center">
        <h3 className="font-bold flex items-center gap-2">
          <i className="fa-solid fa-wand-magic-sparkles text-purple-400"></i>
          AI Design Studio
        </h3>
        <button 
          onClick={() => fileInputRef.current?.click()}
          className="text-xs bg-zinc-700 hover:bg-zinc-600 px-3 py-1 rounded-full transition"
        >
          Upload Source
        </button>
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleFileUpload} 
          className="hidden" 
          accept="image/*"
        />
      </div>

      <div className="grid md:grid-cols-2 gap-4 p-4">
        <div className="relative aspect-[3/4] bg-black rounded-xl overflow-hidden group">
          {videoUrl ? (
            <video src={videoUrl} controls autoPlay loop className="w-full h-full object-cover" />
          ) : (
            <img src={currentImage} alt="Workspace" className="w-full h-full object-cover" />
          )}
          {loading && (
            <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center text-center p-6">
              <div className="w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mb-4"></div>
              <p className="text-sm font-medium">{status}</p>
            </div>
          )}
        </div>

        <div className="flex flex-col gap-4">
          <div className="space-y-2">
            <label className="text-sm text-zinc-400">Enter Prompt</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g., 'Change the hoodie color to neon green' or 'Add a cyberpunk background'"
              className="w-full h-32 bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-sm focus:ring-1 focus:ring-purple-500 outline-none resize-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3 mt-auto">
            <button
              onClick={handleEdit}
              disabled={loading}
              className="bg-zinc-100 text-black font-bold py-3 rounded-xl hover:bg-white transition flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <i className="fa-solid fa-image"></i>
              Edit Image
            </button>
            <button
              onClick={handleAnimate}
              disabled={loading}
              className="bg-purple-600 text-white font-bold py-3 rounded-xl hover:bg-purple-500 transition flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <i className="fa-solid fa-film"></i>
              Veo Animate
            </button>
          </div>
          
          <div className="p-3 bg-zinc-800/50 rounded-xl">
            <p className="text-[10px] text-zinc-500 uppercase tracking-widest mb-1">PRO TIP</p>
            <p className="text-xs text-zinc-400">Combine "Edit" with "Animate" for the ultimate custom piece. Animate uses Veo 3.1 for high-fidelity motion.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GeminiStudio;
