
import React, { useState, useEffect } from 'react';
import { getGeminiSearchResponse } from '../services/geminiService';
import { GroundingSource } from '../types';

const TrendFinder: React.FC = () => {
  const [trends, setTrends] = useState<string>('');
  const [sources, setSources] = useState<GroundingSource[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTrends = async () => {
      try {
        const result = await getGeminiSearchResponse("What are the current streetwear trends for Gen Z in Nigeria for 2024? Mention specific items like hoodies, baggy jeans, and head warmers.");
        setTrends(result.text);
        setSources(result.sources as any);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchTrends();
  }, []);

  return (
    <section className="py-12 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 bg-yellow-400 rounded-full flex items-center justify-center text-black">
            <i className="fa-brands fa-google text-lg"></i>
          </div>
          <div>
            <h2 className="text-2xl font-black italic uppercase tracking-tighter">Live Trend Pulse</h2>
            <p className="text-zinc-500 text-xs">AI-Powered insights via Google Search</p>
          </div>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 md:p-8">
          {loading ? (
            <div className="flex items-center gap-4">
              <div className="w-6 h-6 border-2 border-yellow-400 border-t-transparent rounded-full animate-spin"></div>
              <p className="text-zinc-400 animate-pulse">Scanning global trends...</p>
            </div>
          ) : (
            <>
              <div className="prose prose-invert max-w-none text-zinc-300 leading-relaxed text-sm md:text-base mb-6">
                {trends.split('\n').map((line, i) => (
                  <p key={i} className="mb-2">{line}</p>
                ))}
              </div>
              
              <div className="pt-6 border-t border-zinc-800">
                <p className="text-[10px] text-zinc-500 uppercase font-bold mb-3 tracking-widest">Grounding Sources</p>
                <div className="flex flex-wrap gap-2">
                  {sources.map((s, idx) => s.web && (
                    <a 
                      key={idx} 
                      href={s.web.uri} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="bg-zinc-800 hover:bg-zinc-700 px-3 py-1.5 rounded-lg text-[11px] text-zinc-400 flex items-center gap-2 transition"
                    >
                      <i className="fa-solid fa-link text-[9px]"></i>
                      {s.web.title || "External Source"}
                    </a>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </section>
  );
};

export default TrendFinder;
