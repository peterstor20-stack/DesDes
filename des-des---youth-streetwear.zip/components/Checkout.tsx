
import React, { useState } from 'react';
import { CartItem, PaymentMethod } from '../types';
import { NIGERIAN_BANKS } from '../constants.tsx';

interface CheckoutProps {
  items: CartItem[];
  total: number;
  onClose: () => void;
  onSuccess: () => void;
}

const Checkout: React.FC<CheckoutProps> = ({ items, total, onClose, onSuccess }) => {
  const [step, setStep] = useState<'form' | 'payment' | 'processing'>('form');
  const [method, setMethod] = useState<PaymentMethod>(PaymentMethod.TRANSFER);
  const [selectedBank, setSelectedBank] = useState(NIGERIAN_BANKS[0].name);

  const handleComplete = () => {
    setStep('processing');
    setTimeout(() => {
      onSuccess();
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black flex items-center justify-center p-4">
      <div className="w-full max-w-lg bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="p-6 border-b border-zinc-800 flex justify-between items-center">
          <h2 className="text-xl font-bold italic uppercase tracking-tighter">Secure Checkout</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-zinc-800 hover:bg-zinc-700 flex items-center justify-center">
            <i className="fa-solid fa-xmark"></i>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {step === 'form' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-zinc-500 text-[10px] uppercase font-bold tracking-widest mb-4">Order Summary</h3>
                <div className="space-y-2">
                  {items.map(item => (
                    <div key={item.id} className="flex justify-between text-sm">
                      <span className="text-zinc-400">{item.name} x{item.quantity}</span>
                      <span>₦{(item.price * item.quantity).toLocaleString()}</span>
                    </div>
                  ))}
                  <div className="pt-4 border-t border-zinc-800 flex justify-between font-bold text-lg">
                    <span>Total</span>
                    <span className="text-yellow-400">₦{total.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-zinc-500 text-[10px] uppercase font-bold tracking-widest mb-2">Delivery Details</h3>
                <input type="text" placeholder="Full Name" className="w-full bg-zinc-800 rounded-xl p-4 text-sm border border-transparent focus:border-zinc-600 outline-none" />
                <input type="email" placeholder="Email Address" className="w-full bg-zinc-800 rounded-xl p-4 text-sm border border-transparent focus:border-zinc-600 outline-none" />
                <textarea placeholder="Delivery Address (Nigeria Only)" className="w-full bg-zinc-800 rounded-xl p-4 text-sm border border-transparent focus:border-zinc-600 outline-none h-24" />
              </div>

              <button 
                onClick={() => setStep('payment')}
                className="w-full bg-white text-black font-black py-4 rounded-xl hover:bg-zinc-200 transition uppercase tracking-widest"
              >
                Continue to Payment
              </button>
            </div>
          )}

          {step === 'payment' && (
            <div className="space-y-6">
              <h3 className="text-zinc-500 text-[10px] uppercase font-bold tracking-widest mb-2">Select Payment Method</h3>
              <div className="grid grid-cols-1 gap-3">
                {Object.values(PaymentMethod).map(m => (
                  <button 
                    key={m}
                    onClick={() => setMethod(m)}
                    className={`p-4 rounded-xl border flex items-center justify-between transition ${method === m ? 'bg-zinc-800 border-white' : 'bg-transparent border-zinc-800 hover:border-zinc-700'}`}
                  >
                    <span className="font-medium">{m}</span>
                    {method === m && <i className="fa-solid fa-circle-check text-green-400"></i>}
                  </button>
                ))}
              </div>

              {method === PaymentMethod.TRANSFER && (
                <div className="space-y-4 pt-4 border-t border-zinc-800">
                  <label className="text-sm text-zinc-400">Select Local Bank</label>
                  <select 
                    value={selectedBank}
                    onChange={(e) => setSelectedBank(e.target.value)}
                    className="w-full bg-zinc-800 rounded-xl p-4 text-sm outline-none border border-transparent"
                  >
                    {NIGERIAN_BANKS.map(bank => (
                      <option key={bank.code} value={bank.name}>{bank.name}</option>
                    ))}
                  </select>
                  <div className="bg-zinc-950 p-6 rounded-2xl border border-dashed border-zinc-700 text-center">
                    <p className="text-xs text-zinc-500 mb-1">Send exactly ₦{total.toLocaleString()} to:</p>
                    <p className="text-lg font-bold tracking-tight">0123456789</p>
                    <p className="text-sm font-medium text-zinc-300">Des Des Enterprise Ltd</p>
                    <p className="text-[10px] text-zinc-600 mt-2 uppercase">{selectedBank}</p>
                  </div>
                </div>
              )}

              <div className="pt-4 flex gap-3">
                 <button 
                  onClick={() => setStep('form')}
                  className="flex-1 bg-zinc-800 py-4 rounded-xl font-bold hover:bg-zinc-700"
                >
                  Back
                </button>
                <button 
                  onClick={handleComplete}
                  className="flex-[2] bg-yellow-400 text-black py-4 rounded-xl font-black uppercase tracking-widest hover:bg-yellow-300 transition"
                >
                  I have Made Payment
                </button>
              </div>
            </div>
          )}

          {step === 'processing' && (
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <div className="w-16 h-16 border-4 border-yellow-400 border-t-transparent rounded-full animate-spin mb-6"></div>
              <h3 className="text-2xl font-bold mb-2">Verifying Payment</h3>
              <p className="text-zinc-500 text-sm px-10">We're checking your transaction with {selectedBank}. Hang tight!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Checkout;
